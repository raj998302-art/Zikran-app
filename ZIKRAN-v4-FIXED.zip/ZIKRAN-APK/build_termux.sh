#!/bin/bash
echo ""
echo "🕌 ZIKRAN APK Builder v4 (Gradle 9 compatible)"
echo "══════════════════════════════════════════════"
echo ""

# Set Java
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
export PATH=$JAVA_HOME/bin:$PATH
echo "☕ Java: $(java -version 2>&1 | awk -F '"' '/version/ {print $2}')"
echo "⚙  Gradle: $(gradle --version 2>/dev/null | grep 'Gradle ' | head -1)"
echo ""

cd "$(dirname "$0")"
echo "📁 Project: $(pwd)"
echo ""
echo "🔨 Building APK..."
echo ""

gradle assembleDebug --no-daemon --no-configuration-cache --warning-mode=none 2>&1

APK=$(find . -name "*.apk" -path "*/debug/*" 2>/dev/null | head -1)

echo ""
if [ -n "$APK" ]; then
    SIZE=$(du -k "$APK" | cut -f1)
    echo "✅ SUCCESS! APK built (${SIZE}KB)"
    echo ""
    cp "$APK" ~/storage/downloads/ZIKRAN.apk 2>/dev/null && \
        echo "📲 Copied to Downloads → ZIKRAN.apk" || \
        echo "📁 APK location: $APK"
    echo ""
    echo "👉 Open your file manager → Downloads → tap ZIKRAN.apk → Install"
else
    echo "❌ Build failed. Check errors above."
    echo ""
    echo "💡 Try running with details:"
    echo "   gradle assembleDebug --info --no-daemon"
fi
