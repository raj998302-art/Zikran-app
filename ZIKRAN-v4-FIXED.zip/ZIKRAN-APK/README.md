# 🕌 ZIKRAN — Daily Islamic Remembrance App
## Version 4.0 | APK Build Guide for Termux

---

## 📁 PROJECT STRUCTURE
```
ZIKRAN-APK/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml     ← App permissions & config
│   │   ├── assets/
│   │   │   └── index.html          ← THE FULL APP (2600+ lines)
│   │   ├── java/com/zikran/app/
│   │   │   └── MainActivity.java   ← Native Android wrapper
│   │   └── res/
│   │       ├── values/strings.xml
│   │       ├── values/styles.xml
│   │       ├── values/colors.xml
│   │       └── drawable/ic_launcher.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── build_termux.sh                 ← AUTO BUILD SCRIPT
└── README.md                       ← THIS FILE
```

---

## 📱 HOW TO BUILD APK ON PHONE (TERMUX)

### STEP 1 — Install Termux
Download from F-Droid (NOT Play Store): https://f-droid.org/packages/com.termux/

### STEP 2 — Open Termux and run these commands ONE BY ONE:

```bash
# Update packages
pkg update -y && pkg upgrade -y

# Install Java (required to build APK)
pkg install -y openjdk-17

# Install build tools
pkg install -y gradle

# Check Java works
java -version
```

### STEP 3 — Copy ZIKRAN-APK folder to phone
Put the ZIKRAN-APK folder in your phone storage, e.g.:
`/sdcard/ZIKRAN-APK/`

### STEP 4 — Give Termux storage access
```bash
termux-setup-storage
```
(Allow storage permission when asked)

### STEP 5 — Navigate to the project
```bash
cd /sdcard/ZIKRAN-APK
```

### STEP 6 — Run the build script
```bash
bash build_termux.sh
```

### STEP 7 — Install the APK
After build succeeds, find the APK:
```bash
find . -name "*.apk"
```
Then copy it to Downloads and install, OR:
```bash
# Copy to Downloads
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/ZIKRAN.apk
```
Then open your file manager, go to Downloads, tap ZIKRAN.apk and install.

> ⚠️ Enable "Install from Unknown Sources" in Settings > Security

---

## 🔧 IF GRADLE BUILD FAILS

### Option A — Use Android Studio (PC)
1. Open this folder in Android Studio
2. Click Build > Generate Signed/Debug APK
3. Transfer APK to phone

### Option B — Online APK Builder
1. Go to: https://www.appssgeyser.com
2. Choose "WebView App"
3. Enter URL or upload HTML file
4. Download APK

### Option C — PWA (No APK needed!)
Open index.html in Chrome on Android:
1. Copy index.html to phone
2. Open Chrome, navigate to the file
3. Tap menu (⋮) > "Add to Home Screen"
4. ZIKRAN appears as an app icon — NO BUILD NEEDED!

---

## 📋 APP FEATURES (v4.0)

### 🕌 Prayer Times & Alarms
- Auto-detect location (proper Android permission dialog)
- Live countdown to next prayer
- Individual alarm toggles for each prayer (Fajr, Dhuhr, Asr, Maghrib, Isha)
- Pre-Fajr Tahajjud reminder (30 min before)
- Full-screen alarm overlay with vibration
- Prayer times cached — works offline after first load

### 📿 Tasbeeh Counter (UPGRADED)
- **FREE COUNTER MODE**: 18 dhikr options, custom target, rounds tracking
- **SESSION MODE** (NEW): 10 pre-built complete sessions:
  1. 🌸 Tasbeeh Fatimah (33+33+34)
  2. 🕌 After Every Salah (full sequence)
  3. 🌅 Morning 100 Tasbih
  4. 🤲 100 Istighfar Session
  5. 💚 100 Salawat Session
  6. ⭐ Laylatul Qadr Dua
  7. 📿 Kaffarah Al-Majlis
  8. 🛡️ Ruqyah Self-Healing
  9. 🌿 8 Gates of Jannah
  10. ✨ 99 Names Dhikr
- Haptic feedback on every tap
- Step progress indicator
- Completion celebration with sound

### 📿 Zikr Collection (111 cards total)
- Morning Azkar (17 cards)
- Evening Azkar (16 cards)
- After Salah (10 cards)
- Before Sleep (14 cards)
- After Waking (13 cards)
- Extra Azkar (20 cards)
- All Duas accordion (15 categories)
- Jumu'ah special (5 cards)
- Healing & Ruqyah (6 cards)

### 🧭 Qibla Direction
- Live compass needle pointing to Kaaba
- Uses device orientation sensor
- Shows bearing in degrees
- Reverse geocoded city name

### 📖 Quran Panel
- 7 Surahs with full Arabic text
- Audio recitation (Mishary Alafasy)
- Translation tab

### 📚 Daily Hadith
- 30 authentic hadiths
- Daily rotation by date
- Previous / Next / Random
- Full Arabic + explanation

### 🙏 Salah & Wudu Guide
- 10-step Wudu with Arabic duas
- 10-step Fard Salah guide
- Arabic text for every position

### ✨ 99 Names of Allah
- All 99 names with Arabic, transliteration, meaning
- Search by name, number, or meaning

### ⚙️ Settings
- Font size adjustment (12–22px)
- Vibration toggle
- Sound toggle
- Keep screen on (Wake Lock)
- Reset daily progress

---

## 🔐 PERMISSIONS EXPLAINED
- **INTERNET** — Load prayer times API, Quran audio
- **LOCATION** — Calculate prayer times for your city
- **VIBRATE** — Haptic feedback on tasbeeh tap & alarm
- **WAKE_LOCK** — Keep screen on during recitation
- **POST_NOTIFICATIONS** — Future notification support

---

## 🤲 MADE FOR MUSLIMS
بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ
May Allah accept this effort and make it beneficial.
